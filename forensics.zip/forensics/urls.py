from django.urls import path
from .views import Main, Detail

app_name = 'forensics'

urlpatterns = [
    path('', Main.as_view(), name='main'),
    path('details/<int:flow_id>', Detail.as_view(), name='detail'),
]
