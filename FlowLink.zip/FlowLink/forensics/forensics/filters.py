from django_filters import rest_framework as filters

from forensics.models import Flow


class FlowFilter(filters.FilterSet):

    class Meta:
        model = Flow
        fields = ['src_ip', 'des_ip']
