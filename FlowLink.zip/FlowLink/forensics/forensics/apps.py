from django.apps import AppConfig


class ForensicsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'forensics'
