from rest_framework import serializers

from djvue.fields import FileField

from .models import Flow


class FlowSerializer(serializers.ModelSerializer):
    file = FileField(required=False, label='Flow or Zigbee File')

    class Meta:
        model = Flow
        fields = "__all__"
