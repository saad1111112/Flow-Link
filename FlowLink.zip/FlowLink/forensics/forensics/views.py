
# Create your views here.
import csv
from django.core.exceptions import ObjectDoesNotExist
from collections import defaultdict
from datetime import timedelta

from django.apps import apps

from django.utils.timezone import make_aware
from django_filters import rest_framework as filters
from django.db.models.query_utils import Q
from django.http import JsonResponse
from django.views.generic import ListView
from rest_framework.generics import ListAPIView


from forensics.models import Flow, Zigbee, Device
from forensics.serializers import FlowSerializer
from datetime import datetime


class BulkCreateManager(object):
    """
    This helper class keeps track of ORM objects to be created for multiple
    model classes, and automatically creates those objects with `bulk_create`
    when the number of objects accumulated for a given model class exceeds
    `chunk_size`.
    Upon completion of the loop that's `add()`ing objects, the developer must
    call `done()` to ensure the final set of objects is created for all models.
    """

    def __init__(self, chunk_size=100):
        self._create_queues = defaultdict(list)
        self.chunk_size = chunk_size

    def _commit(self, model_class):
        model_key = model_class._meta.label
        model_class.objects.bulk_create(self._create_queues[model_key])
        self._create_queues[model_key] = []

    def add(self, obj):
        """
        Add an object to the queue to be created, and call bulk_create if we
        have enough objs.
        """
        model_class = type(obj)
        model_key = model_class._meta.label
        self._create_queues[model_key].append(obj)
        if len(self._create_queues[model_key]) >= self.chunk_size:
            self._commit(model_class)

    def done(self):
        """
        Always call this upon completion to make sure the final partial chunk
        is saved.
        """
        for model_name, objs in self._create_queues.items():
            if len(objs) > 0:
                self._commit(apps.get_model(model_name))


class FlowFilter(filters.FilterSet):

    class Meta:
        model = Flow
        fields = ['src_ip', 'des_ip']


class Main(ListView, ListAPIView):
    template_name = "forensics/index.html"
    serializer_class = FlowSerializer
    paginate_by = 100
    model = Flow
    ordering = ['timestamp']

    def get_context_data(self, **kwargs):
        context = super(Main, self).get_context_data(**kwargs)
        context['serializer'] = FlowSerializer()
        context['devices'] = Device.objects.all()
        return context

    def get_queryset(self):
        iot_device = self.request.GET.get("iot_device", None)
        date_range = self.request.GET.get("date_range", None)
        clear_db = self.request.GET.get("clear_db", None)
        queryset = Flow.objects.filter(
            ~Q(event_label='')
        )

        if clear_db:
            Flow.objects.all().delete()
            Zigbee.objects.all().delete()
            Device.objects.all().delete()
            queryset = Flow.objects.none()

        if iot_device:
            queryset = queryset.filter(
                    Q(src_ip=iot_device) | Q(des_ip=iot_device)
            )
        if date_range:
            start = date_range.split('-')[0].strip()
            end = date_range.split('-')[1].strip()
            start_date = datetime.strptime(start, '%m/%d/%Y %I:%M %p')
            end_date = datetime.strptime(end, '%m/%d/%Y %I:%M %p')
            queryset = queryset.filter(
                timestamp__gte=start_date, timestamp__lte=end_date
            )
        return queryset.order_by('timestamp')

    def post(self, request, *args, **kwargs):
        file = request.data.get('file', None)
        with open(file['path']) as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=',')
            line_count = 0
            if 'zigbee' in file['filename'].lower():
                for row in csv_reader:
                    if line_count == 0:
                        line_count += 1
                    else:
                        record_fields = {
                            'tcp_lable': row[0],
                            'frame_number': row[1],
                            'frame_time':
                                make_aware(
                                    datetime.strptime(
                                        row[2], '%Y-%m-%d %H:%M:%S'
                                    )
                                ),
                            'frame_len': row[3],
                            'frame_protocols': row[4],
                            'frame_cap_len': row[5],
                            'zbee_nwk_src': row[6],
                            'zbee_nwk_dst': row[7],
                            'cluster': row[8],
                            'zbee_aps_profile': row[9],
                            'zbee_zcl': row[10],
                            'command_type': row[11],
                            'protocol': row[12],
                            'zbee_nwk_src64': row[13],
                            'sensor': row[14],
                        }
                        zigbee = Zigbee.objects.create(**record_fields)
                        zigbee.save()
                        try:
                            flow = Flow.objects.get(
                                timestamp=zigbee.frame_time,
                                level_label=1,
                                dst_label=zigbee.tcp_lable,
                            )
                        except ObjectDoesNotExist:
                            continue
                        if flow:
                            flow.zigbee = zigbee
                            flow.save()
                        line_count += 1
                        print(line_count)

            else:
                bulk_mgr = BulkCreateManager(chunk_size=1000)
                line_count = 0
                for row in csv_reader:
                    if line_count == 0:
                        line_count += 1
                    else:
                        # Don't create DNS Records.
                        if row[2] == '53' or row[3] == '53':
                            pass
                        else:
                            bulk_mgr.add(
                                Flow(
                                    src_ip=row[0],
                                    des_ip=row[1],
                                    src_port=row[2],
                                    des_port=row[3],
                                    protocol=row[4],
                                    mac=row[5],
                                    timestamp=make_aware(
                                        datetime.strptime(
                                            row[6], '%Y-%m-%d %H:%M:%S'
                                        )
                                    ),
                                    flow_duration=row[7],
                                    flow_byts_s=row[8],
                                    flow_pkts_s=row[9],
                                    fwd_pkts_s=row[10],
                                    bwd_pkts_s=row[11],
                                    tot_fwd_pkts=row[12],
                                    tot_bwd_pkts=row[13],
                                    totlen_fwd_pkts=row[14],
                                    totlen_bwd_pkts=row[15],
                                    fwd_pkt_len_max=row[16],
                                    fwd_pkt_len_min=row[17],
                                    fwd_pkt_len_mean=row[18],
                                    fwd_pkt_len_std=row[19],
                                    bwd_pkt_len_max=row[20],
                                    bwd_pkt_len_min=row[21],
                                    bwd_pkt_len_mean=row[22],
                                    bwd_pkt_len_std=row[23],
                                    pkt_len_max=row[24],
                                    pkt_len_min=row[25],
                                    pkt_len_mean=row[26],
                                    pkt_len_std=row[27],
                                    pkt_len_var=row[28],
                                    fwd_header_len=row[29],
                                    bwd_header_len=row[30],
                                    fwd_seg_size_min=row[31],
                                    fwd_act_data_pkts=row[32],
                                    flow_iat_mean=row[33],
                                    flow_iat_max=row[34],
                                    flow_iat_min=row[35],
                                    flow_iat_std=row[36],
                                    fwd_iat_tot=row[37],
                                    fwd_iat_max=row[38],
                                    fwd_iat_min=row[39],
                                    fwd_iat_mean=row[40],
                                    fwd_iat_std=row[41],
                                    fin_flag_cnt=row[42],
                                    pkt_size_avg=row[43],
                                    init_fwd_win_byts=row[44],
                                    active_max=row[45],
                                    active_min=row[46],
                                    active_mean=row[47],
                                    active_std=row[48],
                                    idle_max=row[49],
                                    idle_min=row[50],
                                    idle_mean=row[51],
                                    idle_std=row[52],
                                    fwd_byts_b_avg=row[53],
                                    fwd_pkts_b_avg=row[54],
                                    fwd_blk_rate_avg=row[55],
                                    fwd_seg_size_avg=row[56],
                                    subflow_fwd_pkts=row[57],
                                    subflow_fwd_byts=row[58],
                                    src_type=row[59],
                                    src_label=row[60],
                                    dst_type=row[61],
                                    dst_label=row[62],
                                    event_label=row[63],
                                    level_label=row[64],
                                )
                            )
                            print(line_count)
                            line_count += 1
                bulk_mgr.done()
                devices_list = Flow.objects.filter(
                    ~Q(src_label='cloud')
                ).values_list('src_label', 'src_ip').distinct()
                for name, ip in devices_list:
                    new_device = Device.objects.create(ip=ip, name=name)
                    new_device.save()

        return JsonResponse({}, status=200)


class Detail(ListView):
    template_name = "forensics/similar_flows.html"
    paginate_by = 10
    ordering = ['timestamp']

    def get_context_data(self, **kwargs):
        context = super(Detail, self).get_context_data(**kwargs)
        context['flow'] = Flow.objects.get(pk=self.request.path.split('/')[-1])
        timeline_start = context['flow'].timestamp + timedelta(
            milliseconds=3000
        )
        timeline_end = context['flow'].timestamp + timedelta(
            milliseconds=context['flow'].flow_duration / 1000
        )
        context['timeline_start'] = timeline_start.strftime(
            "%Y-%m-%d %H:%M:%S"
        )
        context['timeline_end'] = timeline_end.strftime("%Y-%m-%d %H:%M:%S")
        return context

    def get_queryset(self):
        flow_id = self.kwargs.get('flow_id', None)
        flow = Flow.objects.get(id=flow_id)
        from_timestamp = flow.timestamp + timedelta(
            milliseconds=3000
        )
        to_timestamp = from_timestamp + timedelta(
            milliseconds=flow.flow_duration / 1000
        )
        queryset = Flow.objects.filter(
            timestamp__gte=from_timestamp,
            timestamp__lte=to_timestamp
        )
        return queryset.order_by('timestamp')

