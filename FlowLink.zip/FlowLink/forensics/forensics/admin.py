from django.contrib import admin

# Register your models here.
from django.contrib.auth.models import Group

from forensics.models import Device, Zigbee, Flow


@admin.register(Device)
class DeviceAdmin(admin.ModelAdmin):
    pass


@admin.register(Zigbee)
class ZigbeeAdmin(admin.ModelAdmin):
    pass


@admin.register(Flow)
class FlowAdmin(admin.ModelAdmin):
    pass


admin.site.unregister(Group)
