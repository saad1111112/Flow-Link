from datetime import timedelta

from django.db import models

# Create your models here.


class Flow(models.Model):
    src_ip = models.CharField(
        'Source IP Address', max_length=16, null=True, blank=True
    )
    des_ip = models.CharField(
        'Destination IP Address', max_length=16, null=True, blank=True
    )
    src_port = models.IntegerField('Source Port', null=True, blank=True)
    des_port = models.IntegerField('Destination Port', null=True, blank=True)
    protocol = models.IntegerField('Protocol', null=True, blank=True)
    mac = models.CharField('MAC', null=True, blank=True, max_length=32)
    timestamp = models.DateTimeField('Timestamp', null=True, blank=True)
    flow_duration = models.FloatField('Flow Duration', null=True, blank=True)
    flow_byts_s = models.FloatField('flow_byts_s', null=True, blank=True)
    flow_pkts_s = models.FloatField('flow_pkts_s', null=True, blank=True)
    fwd_pkts_s = models.FloatField('fwd_pkts_s', null=True, blank=True)
    bwd_pkts_s = models.FloatField('bwd_pkts_s', null=True, blank=True)
    tot_fwd_pkts = models.FloatField('tot_fwd_pkts', null=True, blank=True)
    tot_bwd_pkts = models.FloatField('tot_bwd_pkts', null=True, blank=True)
    totlen_fwd_pkts = models.FloatField(
        'totlen_fwd_pkts', null=True, blank=True
    )
    totlen_bwd_pkts = models.FloatField(
        'totlen_bwd_pkts', null=True, blank=True
    )
    fwd_pkt_len_max = models.FloatField(
        'fwd_pkt_len_max', null=True, blank=True
    )
    fwd_pkt_len_min = models.FloatField(
        'fwd_pkt_len_min', null=True, blank=True
    )
    fwd_pkt_len_mean = models.FloatField(
        'fwd_pkt_len_mean', null=True, blank=True
    )
    fwd_pkt_len_std = models.FloatField(
        'fwd_pkt_len_std', null=True, blank=True
    )
    bwd_pkt_len_max = models.FloatField(
        'bwd_pkt_len_max', null=True, blank=True
    )
    bwd_pkt_len_min = models.FloatField(
        'bwd_pkt_len_min', null=True, blank=True
    )
    bwd_pkt_len_mean = models.FloatField(
        'bwd_pkt_len_mean', null=True, blank=True
    )
    bwd_pkt_len_std = models.FloatField(
        'bwd_pkt_len_std', null=True, blank=True
    )
    pkt_len_max = models.FloatField('pkt_len_max', null=True, blank=True)
    pkt_len_min = models.FloatField('pkt_len_min', null=True, blank=True)
    pkt_len_mean = models.FloatField('pkt_len_mean', null=True, blank=True)
    pkt_len_std = models.FloatField('pkt_len_std', null=True, blank=True)
    pkt_len_var = models.FloatField('pkt_len_var', null=True, blank=True)
    fwd_header_len = models.FloatField('fwd_header_len', null=True, blank=True)
    bwd_header_len = models.FloatField('bwd_header_len', null=True, blank=True)
    fwd_seg_size_min = models.FloatField(
        'fwd_seg_size_min', null=True, blank=True
    )
    fwd_act_data_pkts = models.FloatField(
        'fwd_act_data_pkts', null=True, blank=True
    )
    flow_iat_mean = models.FloatField('flow_iat_mean', null=True, blank=True)
    flow_iat_max = models.FloatField('flow_iat_max', null=True, blank=True)
    flow_iat_min = models.FloatField('flow_iat_min', null=True, blank=True)
    flow_iat_std = models.FloatField('flow_iat_std', null=True, blank=True)
    fwd_iat_tot = models.FloatField('fwd_iat_tot', null=True, blank=True)
    fwd_iat_max = models.FloatField('fwd_iat_max', null=True, blank=True)
    fwd_iat_min = models.FloatField('fwd_iat_min', null=True, blank=True)
    fwd_iat_mean = models.FloatField('fwd_iat_mean', null=True, blank=True)
    fwd_iat_std = models.FloatField('fwd_iat_std', null=True, blank=True)
    fin_flag_cnt = models.IntegerField('fin_flag_cnt', null=True, blank=True)
    pkt_size_avg = models.FloatField('pkt_size_avg', null=True, blank=True)
    init_fwd_win_byts = models.FloatField(
        'init_fwd_win_byts', null=True, blank=True
    )
    active_max = models.FloatField('active_max', null=True, blank=True)
    active_min = models.FloatField('active_min', null=True, blank=True)
    active_mean = models.FloatField('active_mean', null=True, blank=True)
    active_std = models.FloatField('active_std', null=True, blank=True)
    idle_max = models.FloatField('idle_max', null=True, blank=True)
    idle_min = models.FloatField('idle_min', null=True, blank=True)
    idle_mean = models.FloatField('idle_mean', null=True, blank=True)
    idle_std = models.FloatField('idle_std', null=True, blank=True)
    fwd_byts_b_avg = models.FloatField('fwd_byts_b_avg', null=True, blank=True)
    fwd_pkts_b_avg = models.FloatField('fwd_pkts_b_avg', null=True, blank=True)
    fwd_blk_rate_avg = models.FloatField(
        'fwd_blk_rate_avg', null=True, blank=True
    )
    fwd_seg_size_avg = models.FloatField(
        'fwd_seg_size_avg', null=True, blank=True
    )
    subflow_fwd_pkts = models.FloatField(
        'subflow_fwd_pkts', null=True, blank=True
    )
    subflow_fwd_byts = models.FloatField(
        'subflow_fwd_byts', null=True, blank=True
    )
    src_type = models.CharField(
        'src type', max_length=16, null=True, blank=True
    )
    src_label = models.CharField(
        'src label', max_length=50, null=True, blank=True
    )
    dst_type = models.CharField(
        'dst type', max_length=16, null=True, blank=True
    )
    dst_label = models.CharField(
        'dst label', max_length=50, null=True, blank=True
    )
    event_label = models.CharField(
        'event label', max_length=50, null=True, blank=True
    )
    level_label = models.CharField(
        'level label', max_length=50, null=True, blank=True
    )
    file = models.FileField('File', null=True, blank=True)
    zigbee = models.ForeignKey(
        'Zigbee', on_delete=models.CASCADE, null=True, blank=True
    )

    def get_duration(self):
        duration = timedelta(
            milliseconds=self.flow_duration/1000
        )
        return duration

    def get_flow_end_2(self):
        if self.flow_duration > 0:
            time = self.timestamp + timedelta(
                milliseconds=self.flow_duration/1000
            )
        else:
            time = 0
        return time

    def get_flow_end(self):
        if self.flow_duration > 0:
            flow_end = self.timestamp + timedelta(
                milliseconds=self.flow_duration
            )
        else:
            flow_end = self.timestamp + timedelta(
                milliseconds=5000
            )
        return flow_end

    def __str__(self):
        return 'SRC {}:{}, DST {}:{}'.format(
            self.src_ip, self.src_port, self.des_ip, self.des_port
        )

    class Meta:
        verbose_name = 'Flow'
        verbose_name_plural = 'Flows'
        ordering = ['timestamp__second']


class Zigbee(models.Model):
    tcp_lable = models.CharField(
        'tcp_lable', max_length=16, null=True, blank=True
    )
    frame_number = models.IntegerField('frame_number', null=True, blank=True)
    frame_time = models.DateTimeField('frame_time', null=True, blank=True)
    frame_len = models.IntegerField('frame_len', null=True, blank=True)
    frame_protocols = models.CharField(
        'frame_protocols', max_length=100, null=True, blank=True
    )
    frame_cap_len = models.IntegerField('frame_cap_len', null=True, blank=True)
    zbee_nwk_src = models.CharField(
        'zbee_nwk_src', max_length=100, null=True, blank=True
    )
    zbee_nwk_dst = models.CharField(
        'zbee_nwk_dst', max_length=100, null=True, blank=True
    )
    cluster = models.CharField(
        'cluster', max_length=100, null=True, blank=True
    )
    zbee_aps_profile = models.IntegerField(
        'frame_cap_len', null=True, blank=True
    )
    zbee_zcl = models.TextField(
        'zbee_zcl', null=True, blank=True
    )
    command_type = models.CharField(
        'command_type', max_length=100, null=True, blank=True
    )
    protocol = models.CharField(
        'protocol', max_length=100, null=True, blank=True
    )
    zbee_nwk_src64 = models.CharField(
        'zbee_nwk_src64', max_length=100, null=True, blank=True
    )
    sensor = models.CharField(
        'sensor', max_length=100, null=True, blank=True
    )

    def __str__(self):
        return self.tcp_lable

    class Meta:
        verbose_name = 'Zigbee'
        verbose_name_plural = 'Zigbee'


class Device(models.Model):
    ip = models.CharField(
        'IP Address', max_length=16, null=True, blank=True
    )
    name = models.CharField(
        'Device Name', max_length=100, null=True, blank=True
    )
    guide = models.FileField(upload_to='guides/', null=True, blank=True)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Device'
        verbose_name_plural = 'Devices'
